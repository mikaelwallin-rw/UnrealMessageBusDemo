// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#ifndef __MESSAGINGSERVER_H__
#define __MESSAGINGSERVER_H__

#include "EngineMinimal.h"

#endif

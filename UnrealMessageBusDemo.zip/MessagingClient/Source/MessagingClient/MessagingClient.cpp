// Copyright Epic Games, Inc. All Rights Reserved.

#include "MessagingClient.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, MessagingClient, "MessagingClient" );
